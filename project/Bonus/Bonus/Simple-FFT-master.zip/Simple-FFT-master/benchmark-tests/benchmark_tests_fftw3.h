#ifndef __SIMPLE_FFT__BENCHMARK_TESTS_FFTW3_H
#define __SIMPLE_FFT__BENCHMARK_TESTS_FFTW3_H

namespace simple_fft {
namespace fft_test {

bool BenchmarkTestAgainstFFTW3();

}
}

#endif // __SIMPLE_FFT__BENCHMARK_TESTS_FFTW3_H
